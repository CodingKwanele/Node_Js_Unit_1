// public/js/courses-modal.js
(function () {
  const btn = document.getElementById("modal-button");
  const modal = document.getElementById("myModal");
  if (!btn || !modal) return;

  let inFlight = false;
  const bodyEl = () => modal.querySelector(".modal-body");

  function renderCourses(data) {
    const body = bodyEl();
    if (!body) return;

    const courses = (data && data.courses) || [];
    if (!courses.length) {
      body.innerHTML = "<p class='text-muted'>No courses found.</p>";
      return;
    }

    body.innerHTML =
      '<ul class="list-group">' +
      courses.slice(0, 5).map((c) => {
        const t = (c && c.title) || "(untitled)";
        const d = c && c.description ? `<br><small class="text-muted">${c.description}</small>` : "";
        return `<li class="list-group-item"><strong>${t}</strong>${d}</li>`;
      }).join("") +
      "</ul>";
  }

  function loadCourses() {
    if (inFlight) return;
    inFlight = true;

    const body = bodyEl();
    if (body) body.innerHTML = "<p class='text-muted'>Loading…</p>";

    const url = `/courses?format=json&_=${Date.now()}`;
    fetch(url, {
      cache: "no-store",
      headers: { Accept: "application/json", "Cache-Control": "no-cache", Pragma: "no-cache" }
    })
      .then((r) => r.json())
      .then(renderCourses)
      .catch(() => { if (body) body.innerHTML = "<p class='text-danger'>Failed to load courses.</p>"; })
      .finally(() => { inFlight = false; });
  }

  // Bootstrap 5 show event (no jQuery)
  modal.addEventListener("show.bs.modal", loadCourses);
})();
